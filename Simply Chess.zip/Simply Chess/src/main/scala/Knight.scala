// Knight Class which extends ChessPiece
class Knight(isWhite: Boolean) extends ChessPiece(isWhite) {

  // Override the isValidMove method for the Knight
  override def isValidMove(fromRow: Int, fromCol: Int, toRow: Int, toCol: Int, isCapture: Boolean, board: Array[Array[Option[ChessPiece]]]): Boolean = {
    // Calculate the movement differences in rows and columns
    val verticalMove = Math.abs(toRow - fromRow)
    val horizontalMove = Math.abs(toCol - fromCol)

    // Knights move in an L shape: either two squares in one direction and one in the other
    val isLShapeMove = (verticalMove == 2 && horizontalMove == 1) || (verticalMove == 1 && horizontalMove == 2)

    // Return true if it's a valid L-shaped move
    isLShapeMove
  }
}
