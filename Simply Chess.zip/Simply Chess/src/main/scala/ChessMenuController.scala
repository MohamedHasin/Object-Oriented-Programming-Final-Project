import javafx.fxml.FXMLLoader
import scalafx.application.Platform
import scalafx.scene.control.Button
import scalafxml.core.macros.sfxml

// Define the controller for the chess menu using the @sfxml macro
@sfxml
class ChessMenuController(
                           val startButton: Button,
                           val howToPlayButton: Button,
                           val quitButton: Button
                         ) {

  // Function to handle the action when the Start button is clicked
  def handleStartAction(): Unit = {
    val currentStage = startButton.getScene.getWindow.asInstanceOf[javafx.stage.Stage]
    SimplyChessApp.setGameScene(currentStage)
  }

  // Function to handle the action when the How to Play button is clicked
  def handleHowToPlayAction(): Unit = {
    val currentStage = howToPlayButton.getScene.getWindow.asInstanceOf[javafx.stage.Stage]
    val guideRoot: javafx.scene.Parent = FXMLLoader.load(getClass.getResource("Guide.fxml"))
    val guideScene = new javafx.scene.Scene(guideRoot)
    currentStage.setScene(guideScene)
  }

  // Function to handle the action when the Quit button is clicked
  def handleQuitAction(): Unit = {
    // exit the application
    Platform.exit()
  }
}
