import javafx.fxml.FXML
import javafx.scene.control.Button

// This class handles the guide screen in the Chess App
class GuideController {

  // The startButton starts the game from the guide screen
  @FXML
  private var startButton: Button = _

  // This method is called when the startButton is clicked
  @FXML
  def handleStartAction(): Unit = {
    val currentStage = startButton.getScene.getWindow.asInstanceOf[javafx.stage.Stage]
    SimplyChessApp.setGameScene(currentStage)
  }

}
