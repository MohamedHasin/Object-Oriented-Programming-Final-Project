// Rook Class which extends ChessPiece
class Rook(isWhite: Boolean) extends ChessPiece(isWhite) {

  // Overriding the isValidMove method to define how a Rook can move
  override def isValidMove(fromRow: Int, fromCol: Int, toRow: Int, toCol: Int, isCapture: Boolean, board: Array[Array[Option[ChessPiece]]]): Boolean = {

    // Calculate the differences in rows and columns to determine the direction of movement
    val rowDifference = Math.abs(toRow - fromRow)
    val colDifference = Math.abs(toCol - fromCol)

    // Rook should move in a straight line, either row or column will be the same
    if (fromRow != toRow && fromCol != toCol) {
      return false
    }

// Check every square between the starting and ending positions
    val rowDirection = Integer.signum(toRow - fromRow)
    val colDirection = Integer.signum(toCol - fromCol)

    // Starting point for checking the path
    var checkRow = fromRow + rowDirection
    var checkCol = fromCol + colDirection

    // Loop to check each square on the path for any blocking pieces
    while (checkRow != toRow || checkCol != toCol) {
      if (board(checkRow)(checkCol).isDefined) {
        // A piece is blocking the way
        return false
      }
      checkRow += rowDirection
      checkCol += colDirection
    }

    // Check if the destination square is occupied by a piece of the same color
    if (board(toRow)(toCol).isDefined && board(toRow)(toCol).get.isWhite == this.isWhite) {
      return false // Can't capture your own piece
    }

    // The path is clear and the destination square is valid
    true
  }
}


