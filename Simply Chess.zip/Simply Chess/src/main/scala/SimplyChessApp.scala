import scalafx.Includes._
import scalafx.animation.PauseTransition
import scalafx.application.JFXApp
import scalafx.application.JFXApp.PrimaryStage
import scalafx.geometry.Pos
import scalafx.scene.control.Label
import scalafx.scene.image.{Image, ImageView}
import scalafx.scene.layout.{GridPane, StackPane, VBox}
import scalafx.scene.{Parent, Scene}
import scalafxml.core.{FXMLLoader, NoDependencyResolver}

// Main object for the chess application`
object SimplyChessApp extends JFXApp {
  var primaryStage: PrimaryStage = _

  // Chessboard size configuration
  private val gridSize = 8
  private val squareSize = 100.0

  // Keeps track of turns to determine which player's turn it is
  private var turnIndicator: Int = 0

  // To keep track of the currently selected chess piece
  private var selectedPiece: Option[BoardSquare] = None

  // Status label for displaying messages at the bottom of the screen
  val statusLabel: Label = new Label {
    style = "-fx-font-size: 20pt; -fx-background-color: white; -fx-border-color: black; -fx-border-width: 2px;"
    textFill = scalafx.scene.paint.Color.Red
    layoutX = 20
    layoutY = squareSize * gridSize + 10
    prefWidth = squareSize * gridSize
    alignment = Pos.Center // Center align the text in the label
  }

  // Initialize the board as a 2D array to hold chess pieces
  private val board: Array[Array[Option[ChessPiece]]] = Array.fill(gridSize, gridSize)(None)

  // Setting up the grid for the chessboard
  private val squareMatrix: GridPane = new GridPane {
    gridLinesVisible = true
    for (row <- 0 until gridSize; col <- 0 until gridSize) {
      val cellIndex = (gridSize - row - 1) * gridSize + col
      val cell = new BoardSquare(cellIndex)
      this.add(cell, col, row)
    }
  }

  // Function to set up the game scene
  def setGameScene(stage: javafx.stage.Stage): Unit = {
    val layout = new VBox()
    layout.children.addAll(squareMatrix, statusLabel)
    val gameScene = new Scene(layout, squareSize * gridSize, squareSize * gridSize + 70)
    stage.setScene(gameScene)
  }

  // Initialize the primary stage and scene
  stage = new PrimaryStage {
    title = "Simply Chess"
    scene = loadMenuScene()
    resizable = false // Make the window not resizable
  }

  // Function to load the menu scene from an FXML file
  private def loadMenuScene(): Scene = {
    val resource = getClass.getResource("/Menu.fxml")
    if (resource == null) {
      throw new Exception("Cannot load resource: Menu.fxml")
    }
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load()
    val root: Parent = loader.getRoot[javafx.scene.Parent]
    new Scene(root)
  }

  // Function to get the current player based on the turn indicator
  def getCurrentPlayer: String = if (turnIndicator % 2 == 0) "Black" else "White"

  // Class representing each square on the chessboard
  private class BoardSquare(index: Int) extends StackPane {
    private val isBlackBoardSquare = (index / gridSize + index % gridSize) % 2 == 1
    private val cellColor: String = if (isBlackBoardSquare) "#FA8072" else "#FFEFED"
    style = s"-fx-background-color: $cellColor;"
    prefWidth = squareSize
    prefHeight = squareSize
    private var pieceChar: Char = ' '
    private val row: Int = index / gridSize
    private val col: Int = index % gridSize
    private var isMovingPiece = false

    // Map of chess piece characters to their images
    private val chessPieceImages: Map[Char, Image] = Map(
      'r' -> new Image(getClass.getResourceAsStream("/White_Rook.png")),
      'n' -> new Image(getClass.getResourceAsStream("/White_Knight.png")),
      'b' -> new Image(getClass.getResourceAsStream("/White_Bishop.png")),
      'q' -> new Image(getClass.getResourceAsStream("/White_Queen.png")),
      'k' -> new Image(getClass.getResourceAsStream("/White_King.png")),
      'p' -> new Image(getClass.getResourceAsStream("/White_Pawn.png")),
      'R' -> new Image(getClass.getResourceAsStream("/Black_Rook.png")),
      'N' -> new Image(getClass.getResourceAsStream("/Black_Knight.png")),
      'B' -> new Image(getClass.getResourceAsStream("/Black_Bishop.png")),
      'Q' -> new Image(getClass.getResourceAsStream("/Black_Queen.png")),
      'K' -> new Image(getClass.getResourceAsStream("/Black_King.png")),
      'P' -> new Image(getClass.getResourceAsStream("/Black_Pawn.png"))
    )

    // Image view for displaying the chess piece
    private val pieceImageView = new ImageView {
      preserveRatio = true
      fitWidth = squareSize
      fitHeight = squareSize
    }

    // Event handler for mouse clicks on a square
    onMouseClicked = _ => processSquareSelection()

    // Function to set a chess piece on this square
    private def setPiece(pieceChar: Char): Unit = {
      chessPieceImages.get(pieceChar) match {
        case Some(pieceImage) =>
          pieceImageView.image = pieceImage
          if (!children.contains(pieceImageView)) {
            children.add(pieceImageView)
          }
        case None =>
          println(s"Image for piece '$pieceChar' not found.")
      }
      this.pieceChar = pieceChar
    }

    // Initialize the piece on this square based on its position
    setInitialPieceForRowAndCol(index / gridSize, index % gridSize)

    // Function to determine the initial piece based on the square's position
    private def setInitialPieceForRowAndCol(row: Int, col: Int): Unit = {
      val initialPiece = (row, col) match {
        case (0, 0) | (0, 7) => 'R'
        case (0, 1) | (0, 6) => 'N'
        case (0, 2) | (0, 5) => 'B'
        case (0, 3) => 'Q'
        case (0, 4) => 'K'
        case (7, 0) | (7, 7) => 'r'
        case (7, 1) | (7, 6) => 'n'
        case (7, 2) | (7, 5) => 'b'
        case (7, 3) => 'q'
        case (7, 4) => 'k'
        case (6, _) => 'p'
        case (1, _) => 'P'
        case _ => ' '
      }
      // Only call setPiece if there is a piece to set
      if (initialPiece != ' ') {
        setPiece(initialPiece)
      }
    }

    // Function to handle the selection and movement of a piece
    private def processSquareSelection(): Unit = {
      if (!isMovingPiece) {
        val currentPlayerIsWhite = turnIndicator % 2 == 0
        if ((currentPlayerIsWhite && pieceChar.isUpper) || (!currentPlayerIsWhite && pieceChar.isLower)) {
          if (selectedPiece.isEmpty && pieceChar != ' ') {
            isMovingPiece = true
            selectedPiece = Option(this)
          }
        }

        if (selectedPiece.isDefined && this != selectedPiece.get) {
          val selectedBoardSquare = selectedPiece.get
          val selectedPieceChar = selectedBoardSquare.pieceChar

          // Calculate if this is a diagonal move for pawns
          val isDiagonalPawnMove = selectedPieceChar.toUpper == 'P' &&
            Math.abs(col - selectedBoardSquare.col) == 1

          // A move is a capture attempt if:
          // 1. It's a diagonal pawn move AND there's an opponent's piece, or
          // 2. The target square has an opponent's piece
          val targetHasPiece = pieceChar != ' '
          val isOpponentPiece = targetHasPiece &&
            (selectedPieceChar.isUpper != pieceChar.isUpper)

          val isCapture = (isDiagonalPawnMove && isOpponentPiece) ||
            (targetHasPiece && isOpponentPiece)

          val isValid = selectedPieceChar.toUpper match {
            case 'P' => new Pawn(!selectedPieceChar.isUpper).isValidMove(selectedBoardSquare.row, selectedBoardSquare.col, row, col, isCapture, board)            case 'R' => new Rook(selectedPieceChar.isUpper).isValidMove(selectedBoardSquare.row, selectedBoardSquare.col, row, col, isCapture, board)
            case 'N' => new Knight(selectedPieceChar.isUpper).isValidMove(selectedBoardSquare.row, selectedBoardSquare.col, row, col, isCapture, board)
            case 'B' => new Bishop(selectedPieceChar.isUpper).isValidMove(selectedBoardSquare.row, selectedBoardSquare.col, row, col, isCapture, board)
            case 'Q' => new Queen(selectedPieceChar.isUpper).isValidMove(selectedBoardSquare.row, selectedBoardSquare.col, row, col, isCapture, board)
            case 'K' => new King(selectedPieceChar.isUpper).isValidMove(selectedBoardSquare.row, selectedBoardSquare.col, row, col, isCapture, board)
            case _ => false
          }

          if (isValid) {
            val isWhiteTurn = turnIndicator % 2 == 0
            val targetChar = pieceChar
            val isTargetOccupiedByOpponent = targetChar != ' ' && isWhiteTurn != targetChar.isUpper
            if (isTargetOccupiedByOpponent || targetChar == ' ') {
              setPiece(selectedPieceChar)
              selectedBoardSquare.clearPiece()
              selectedPiece = None
              isMovingPiece = false
              turnIndicator += 1
              SimplyChessApp.statusLabel.text = s"$getCurrentPlayer's turn"
              val pause = new PauseTransition(javafx.util.Duration.seconds(2))
              pause.onFinished = handle {
                SimplyChessApp.statusLabel.text = ""
              }
              pause.play()
            } else {
              SimplyChessApp.statusLabel.text = "Invalid move. Target cell is occupied by a piece of the same color."
              val pause = new PauseTransition(javafx.util.Duration.seconds(2))
              pause.onFinished = handle {
                SimplyChessApp.statusLabel.text = ""
              }
              pause.play()
              deselectPieceAndBoardSquare()
            }
          } else {
            SimplyChessApp.statusLabel.text = "Invalid move."
            val pause = new PauseTransition(javafx.util.Duration.seconds(2))
            pause.onFinished = handle {
              SimplyChessApp.statusLabel.text = ""
            }
            pause.play()
            deselectPieceAndBoardSquare()
          }
        }
      }
    }

    // Function to deselect a piece and reset the board square state
    private def deselectPieceAndBoardSquare(): Unit = {
      if (selectedPiece.isDefined) {
        selectedPiece.get.isMovingPiece = false
      }
      selectedPiece = None
      isMovingPiece = false
    }

    // Function to clear the chess piece from this square
    private def clearPiece(): Unit = {
      children.clear()
      pieceChar = ' '
    }
  }
}