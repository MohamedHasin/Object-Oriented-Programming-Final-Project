// Pawn Class which extends ChessPiece
class Queen(isWhite: Boolean) extends ChessPiece(isWhite) {

  // Override the method to check if a move is valid for the Queen
  override def isValidMove(fromRow: Int, fromCol: Int, toRow: Int, toCol: Int, isCapture: Boolean, board: Array[Array[Option[ChessPiece]]]): Boolean = {

    // Calculate the differences in rows and columns to understand the direction of the move
    val rowDifference = Math.abs(toRow - fromRow)
    val colDifference = Math.abs(toCol - fromCol)

    // Check for a valid queen movement (either horizontal, vertical, or diagonal)
    if (!(fromRow == toRow || fromCol == toCol || rowDifference == colDifference)) {
      return false
    }

    // Determine the direction of movement in rows and columns
    val rowDirection = if (fromRow == toRow) 0 else if (toRow > fromRow) 1 else -1
    val colDirection = if (fromCol == toCol) 0 else if (toCol > fromCol) 1 else -1

    // Start checking the path for any obstacles
    var currentRow = fromRow + rowDirection
    var currentCol = fromCol + colDirection

    // Loop through each square along the path to the destination
    while (currentRow != toRow || currentCol != toCol) {
      // If there's a piece in the way, the move is not valid
      if (board(currentRow)(currentCol).isDefined) return false

      // Move to the next square in the path
      currentRow += rowDirection
      currentCol += colDirection
    }

    // Check the final destination square
    board(toRow)(toCol) match {
      case Some(piece) if piece.isWhite == this.isWhite => false // Can't capture your own piece
      case Some(piece) => isCapture // Can capture if it's an opponent's piece
      case None => true // The move is valid if the destination square is empty
    }

  }
}
