class Pawn(isWhite: Boolean) extends ChessPiece(isWhite) {
  override def isValidMove(fromRow: Int, fromCol: Int, toRow: Int, toCol: Int, isCapture: Boolean, board: Array[Array[Option[ChessPiece]]]): Boolean = {

    val direction = if (isWhite) -1 else 1

    val rowDiff = toRow - fromRow
    val colDiff = Math.abs(toCol - fromCol)

    if (isCapture) {
      return rowDiff == direction && colDiff == 1
    }

    if (colDiff != 0) return false

    if (rowDiff == direction) {
      return !board(toRow)(toCol).isDefined
    }

    val startingRow = if (isWhite) 6 else 1
    if (fromRow == startingRow && rowDiff == 2 * direction) {
      val intermediateRow = fromRow + direction
      return !board(intermediateRow)(fromCol).isDefined &&
        !board(toRow)(toCol).isDefined
    }

    false
  }
}