// King Class which extends ChessPiece
class King(isWhite: Boolean) extends ChessPiece(isWhite) {

  // Override the isValidMove method to define how the King can move
  override def isValidMove(fromRow: Int, fromCol: Int, toRow: Int, toCol: Int, isCapture: Boolean, board: Array[Array[Option[ChessPiece]]]): Boolean = {

    // Calculate the difference in rows and columns to determine the distance of the move
    val rowDifference = Math.abs(toRow - fromRow)
    val colDifference = Math.abs(toCol - fromCol)

    // Check if the move is one square in any direction
    (rowDifference <= 1 && colDifference <= 1) && {
      // The King cannot move to a square occupied by a piece of the same color
      board(toRow)(toCol).forall(p => p.isWhite != this.isWhite)
    }
  }
}
