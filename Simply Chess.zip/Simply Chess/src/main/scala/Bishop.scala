// Bishop Class which extends ChessPiece
class Bishop(isWhite: Boolean) extends ChessPiece(isWhite) {

  // Override the method to check if a move is valid for the Bishop
  override def isValidMove(fromRow: Int, fromCol: Int, toRow: Int, toCol: Int, isCapture: Boolean, board: Array[Array[Option[ChessPiece]]]): Boolean = {

    // Calculate the row and column differences between the start and destination
    val rowDifference = Math.abs(toRow - fromRow)
    val colDifference = Math.abs(toCol - fromCol)

    if (rowDifference != colDifference) {
      return false // Not a diagonal move
    }

    // Bishops move diagonally, so row and column differences are the same
    val rowDirection = Integer.signum(toRow - fromRow)
    val colDirection = Integer.signum(toCol - fromCol)

    // Determine the direction of movement in rows and columns
    var currentRow = fromRow + rowDirection
    var currentCol = fromCol + colDirection

    // Check each square along the path for other pieces
    while (currentRow != toRow || currentCol != toCol) {
      if (board(currentRow)(currentCol).isDefined) {
        return false // A piece is in the way
      }

      // Move to the next square along the diagonal
      currentRow += rowDirection
      currentCol += colDirection
    }

    // Check the final destination square
    board(toRow)(toCol) match {
      case Some(piece) if piece.isWhite == this.isWhite => false // Can't capture your own piece
      case Some(piece) => isCapture // Can capture if it's an opponent's piece
      case None => true // The move is valid if the destination square is empty
    }
  }
}
